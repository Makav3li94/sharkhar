<?php echo '<?xml version="1.0" encoding="UTF-8"?>'; ?>

<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <sitemap>
        <loc>https://sharkhar.net/sitemap/main.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://sharkhar.net/sitemap/articles.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://sharkhar.net/sitemap/categories.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://sharkhar.net/sitemap/tags.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://sharkhar.net/sitemap/vendors.xml</loc>
    </sitemap>

    <sitemap>
        <loc>https://sharkhar.net/sitemap/products-part-1.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://sharkhar.net/sitemap/products-part-2.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://sharkhar.net/sitemap/products-part-3.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://sharkhar.net/sitemap/products-part-4.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://sharkhar.net/sitemap/products-part-5.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://sharkhar.net/sitemap/products-part-6.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://sharkhar.net/sitemap/products-part-7.xml</loc>
    </sitemap>
    <sitemap>
        <loc>https://sharkhar.net/sitemap/products-part-8.xml</loc>
    </sitemap>
{{--    <sitemap>--}}
{{--        <loc>https://sharkhar.net/sitemap.xml/products-part-9</loc>--}}
{{--    </sitemap>--}}
{{--    <sitemap>--}}
{{--        <loc>https://sharkhar.net/sitemap.xml/products-part-10</loc>--}}
{{--    </sitemap>--}}
</sitemapindex>
