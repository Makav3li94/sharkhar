<?php if(auth()->guard('web')->check()): ?>
    <div class="container">
        <ul class="list-unstyled">
            <li class="nav-item ">
                <?php if(auth()->guard('web')->user()->sheba == null): ?>

                    <?php if(request()->is('seller/profile/*')): ?>
                        <a href="javascript:void(0)" id="move-to-sheba">
                            <div class="alert alert-danger">تکمیل اطلاعات واریز، جهت پرداخت پول به شما ...</div>
                        </a>
                    <?php else: ?>
                        <a href="<?php echo e(route('seller.profile',auth()->user()->id)); ?>">
                            <div class="alert alert-danger">تکمیل اطلاعات واریز، جهت پرداخت پول به شما ...</div>
                        </a>
                    <?php endif; ?>

                <?php else: ?>
                    <?php if(auth()->guard('web')->user()->id_card == null): ?>

                        <?php if(request()->is('seller/profile/*')): ?>
                            <a href="javascript:void(0)" id="move-to-ids">
                                <div class="alert alert-danger">لطفا تصویر کارت ملی خود را جهت مطابقت با شماره شبا وارد
                                    کنید.
                                </div>
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('seller.profile',auth()->user()->id)); ?>">
                                <div class="alert alert-danger">لطفا تصویر کارت ملی خود را جهت مطابقت با شماره شبا وارد
                                    کنید.
                                </div>
                            </a>
                        <?php endif; ?>


                    <?php else: ?>
                        <?php if(auth()->guard('web')->user()->is_verified == 'green' ): ?>
                            <a href="<?php echo e(route('seller.products.index')); ?>">
                                <div class="alert alert-info">
                                    تبریک، شما تایید شدید ! حالا کافیه از طریق بخش محصولات کپی لینک خرید رو برای مشتری
                                    بفرستید
                                    و بقیش با ما !
                                </div>
                            </a>
                        <?php elseif(auth()->guard('web')->user()->is_verified == 'info' ): ?>
                            <a href="<?php echo e(route('seller.products.index')); ?>">
                                <div class="alert alert-secondary">
                                    اطلاعات شما در حال بررسی است.
                                </div>
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('seller.contacts.create')); ?>">
                                <div class="alert alert-danger">
                                    متاسفانه شما تایید هویت نشدید.
                                </div>
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>

                <?php endif; ?>
            </li>
        </ul>
    </div>
<?php endif; ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/layouts/seller_includes/alerts.blade.php ENDPATH**/ ?>