
<?php $__env->startSection('content'); ?>
    <div class="authentication">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-sm-12">
                    <form class="card auth_form" action="<?php echo e(route('login')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <div class="header">
                            <img src="<?php echo e(asset('assets/images/logo-p.png')); ?>" width="80px" alt="شرخر">
                            <h5>ورود</h5>
                        </div>
                        <div class="body">

                            <div class="input-group mb-3">
                                <input type="text" name="mobile" class="form-control" placeholder="شماره موبایل "
                                       value="<?php echo e(old('mobile')); ?>" oninput="setCustomValidity('')"
                                       oninvalid="this.setCustomValidity('لطفا شماره تلفن را وارد کنید')" required>
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="zmdi zmdi-phone"></i></span>
                                </div>
                                <?php if($errors->has('mobile')): ?>
                                    <small class="text-danger d-inline-block w-100  mt-2">
                                        <?php echo e($errors->first('mobile')); ?>

                                    </small>
                                <?php endif; ?>
                            </div>
                            <div class="input-group mb-3">
                                <input type="password" name="password" class="form-control" placeholder="رمزعبور"
                                       oninput="setCustomValidity('')"
                                       oninvalid="this.setCustomValidity('لطفا رمز عبور را وارد کنید')" required>
                                <div class="input-group-append">
                                    <span class="input-group-text">
                                        <a href="<?php echo e(url('password/reset')); ?>"  class="forgot " title="فراموشی رمز عبور">
                                            <i class="zmdi zmdi-lock"></i>
                                        </a>
                                    </span>
                                    <?php if($errors->has('password')): ?>
                                        <small class="text-danger d-inline-block w-100  mt-2">
                                            <?php echo e($errors->first('password')); ?>

                                        </small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="checkbox">
                                <input id="remember_me" name="remember"
                                       type="checkbox" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                <label for="remember_me">مرا به خاطر بسپار</label>
                            </div>
                            <button type="submit" class="btn btn-primary btn-block waves-effect waves-light">ورود
                            </button>
                            <div class="signin_with mt-3">
                                <p class="mb-0">اولین بارته ؟، <a href="<?php echo e(route('register')); ?>" title="ثبت نام در شرخر">ثبت
                                        نام کن !</a></p>
                            </div>
                        </div>
                    </form>
                    <div class="copyright text-center">
                        &copy;
                        <script>document.write(new Date().getFullYear())</script>
                        ,کلیه حقوق محفوظ است.شرخر!
                        
                    </div>
                </div>
                <div class="col-lg-8 col-sm-12">
                    <div class="card">
                        <img src="<?php echo e(asset('assets/images/signin.svg')); ?>" alt="Sign In"/>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        small {
            text-align: right !important;
            margin-bottom: 5px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/bootstrap-notify/bootstrap-notify.js')); ?>"></script> <!-- Bootstrap Notify Plugin Js -->
    <?php if(session('newPassSent')): ?>
        <script>
            var allowDismiss = true;
            $.notify({
                    message: "رمز عبور جدید برای شما ارسال شد."
                },
                {
                    type: 'alert-success',
                    allow_dismiss: allowDismiss,
                    newest_on_top: true,
                    timer: 3000,
                    placement: {
                        from: 'bottom',
                        align: 'left'
                    },
                    template: '<div data-notify="container" class="bootstrap-notify-container alert alert-dismissible {0} ' + (allowDismiss ? "" : "") + '" role="alert">' +
                        '<button type="button" aria-hidden="true" class="close" data-notify="dismiss">×</button>' +
                        '<span data-notify="icon"></span> ' +
                        '<span data-notify="title">{1}</span> ' +
                        '<span data-notify="message">{2}</span>' +
                        '<div class="progress" data-notify="progressbar">' +
                        '<div class="progress-bar progress-bar-{0}" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
                        '</div>' +
                        '<a href="{3}" target="{4}" data-notify="url"></a>' +
                        '</div>'
                });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/seller/login.blade.php ENDPATH**/ ?>