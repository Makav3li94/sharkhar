

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row clearfix">

                <div class="card">
                    <div class="header">
                        <h2><strong>اطلاعات</strong> تیکت</h2>
                    </div>
                    <div class="body">
                        <div class="col-lg-12 col-md-12">
                        <ul class="comment-reply list-unstyled">
                            <li class="comment-user">

                                <div class="icon-box w50 ml-2">
                                    <img class="rounded-circle " width="50px"
                                         src="<?php echo e($contact->seller->logo); ?>" alt="Awesome Image">
                                </div>
                                <div class="text-box ">
                                    <h5><?php echo e($contact->seller->name); ?></h5>
                                    <span class="comment-date"><?php echo e($contact->created_at); ?></span>
                                </div>
                            </li>
                            <li>
                                <div class="w50 ml-2"></div>
                                <div class="comment-text">
                                    <p><?php echo e($contact->body); ?></p>
                                </div>
                            </li>
                            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($ticket->seller_id == 1): ?>
                                    <li class="comment-user">

                                            <div class="icon-box w50 ml-2">
                                                <img class="rounded-circle " width="50px"
                                                     src="<?php echo e($ticket->seller->logo); ?>" alt="<?php echo e($ticket->seller->insta_user); ?>">
                                            </div>
                                            <div class="text-box ">
                                                <h5><?php echo e($ticket->seller->name); ?></h5>
                                                <span class="comment-date"><?php echo e($ticket->created_at); ?></span>
                                            </div>
                                    </li>
                                <li>
                                    <div class="w50 ml-2"></div>
                                    <div class="comment-text">
                                    <p><?php echo e($ticket->body); ?></p>
                                    </div>
                                </li>
                                <?php elseif($ticket->admin_id == 1 ): ?>
                                    <li class="comment-user">

                                        <div class="icon-box w50 ml-2">
                                            <img src="<?php echo e(asset('assets/images/logo-p.png')); ?>" width="80px" alt="شرخر">


                                        </div>
                                        <div class="text-box ">
                                            <h5>پشتیبانی شرخر</h5>
                                            <span class="comment-date"><?php echo e($ticket->created_at); ?></span>
                                        </div>
                                    </li>
                                    <li>
                                        <div class="w50 ml-2"></div>
                                        <div class="comment-text">
                                            <p><?php echo e($ticket->reply); ?></p>
                                        </div>
                                    </li>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                           </ul>

                        <form action="<?php echo e(route('seller.contacts.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="parent_id" value="<?php echo e($contact->id); ?>">
                            
                            <div class="col-sm-12 p-0">
                                <div class="form-group">
                                    <div class="form-line">
                                            <textarea rows="4" name="body" class="form-control no-resize"
                                                      placeholder="متن تیکت ..."></textarea>
                                    </div>
                                </div>
                            </div>
                            <?php if($errors->has('body')): ?>
                                <small class="text-danger d-inline-block w-100  mt-2">
                                    <?php echo e($errors->first('body')); ?>

                                </small>
                            <?php endif; ?>
                            <div class="text-center">
                                <button type="submit" class="btn btn-raised btn-primary btn-round waves-effect">ارسال
                                    پاسخ
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>
    <style>
        small {
            text-align: right !important;
            margin-bottom: 5px;
        }
        .comment-user{
            background-color:  #f8f9fa;
            padding: 15px 10px;
            border-top: 1px solid #e0e4e7;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/dropify/css/dropify.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(asset('assets/plugins/dropify/js/dropify.min.js')); ?>"></script>
    <script>
        $(document).ready(function () {

            "use strict";
            $('.dropify').dropify({
                messages: {}
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout',['title' => 'بررسی تیکت','b_level2'=>'بررسی تیکت','back'=>'true'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/seller/contact/edit.blade.php ENDPATH**/ ?>