
<?php $__env->startSection('content'); ?>






    <div class="authentication">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-sm-12">
                    <form class="card auth_form" action="<?php echo e(route('register')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="header">
                            <img src="<?php echo e(asset('assets/images/logo-p.png')); ?>" width="80px" alt="شرخر">
                            <h5>ثبت نام</h5>
                            <span>عضویت جدید را ثبت کنید</span>
                        </div>
                        <div class="body">

                            <div class="input-group mb-3">
                                <input type="text" name="mobile" class="form-control" placeholder="شماره موبایل"
                                       value="<?php echo e(old('mobile')); ?>" oninput="setCustomValidity('')" oninvalid="this.setCustomValidity('لطفا شماره موبایل را وارد کنید')" required>
                                <div class="input-group-append">
                                    <span class="input-group-text"><i class="zmdi zmdi-phone"></i></span>
                                </div>
                                <?php if($errors->has('mobile')): ?>
                                    <small class="text-danger d-inline-block w-100  mt-2">
                                        <?php echo e($errors->first('mobile')); ?>

                                    </small>
                                <?php endif; ?>
                            </div>

                            <div class="input-group mb-3">
                                <input class="form-control text-dark text-center font-16"
                                       type="text"
                                       required="" placeholder="<?php echo e($array[2].' '.$array[1].' '.$array[0]); ?> برابر با چه عددی است؟ "  name="result">
                                <input type="hidden" name="a" value="<?php echo e($array[0]); ?>">
                                <input type="hidden" name="operator" value="<?php echo e($array[1]); ?>">
                                <input type="hidden" name="b" value="<?php echo e($array[2]); ?>">
                                <?php if($errors->has('code')): ?>
                                    <small class="text-danger d-inline-block w-100  mt-2">
                                        <?php echo e($errors->first('code')); ?>

                                    </small>
                                <?php endif; ?>
                            </div>
                            <input type="hidden" name="confirm" value="on">
                            <button type="submit" class="btn btn-primary btn-block waves-effect waves-light">دریافت کد تایید
                            </button>
                            <div class="signin_with mt-3">
                                <p class="mb-0">ثبت نام کردی ؟ <a href="<?php echo e(route('login')); ?>" class="text-danger" title="ورود به شرخر">وارد
                                        شو</a></p>
                            </div>
                        </div>
                    </form>
                    <div class="copyright text-center">
                        &copy;
                        <script>document.write(new Date().getFullYear())</script>
                        ,کلیه حقوق محفوظ است.شرخر!
                    </div>
                </div>
                <div class="col-lg-8 col-sm-12">
                    <div class="card">
                        <img src="<?php echo e(asset('assets/images/final1.png')); ?>" alt="Sign Up"/>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        small{
            text-align: right!important;
            margin-bottom: 5px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/seller/register.blade.php ENDPATH**/ ?>