
<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12">
                <div class="card">
                    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blogitem mb-5 p-5">
                            <div class="blogitem-image">
                                <a href="<?php echo e(route('blogs.show',$blog->slug)); ?>">
                                    <img src="<?php echo e(asset($blog->image)); ?>" alt="<?php echo e($blog->title); ?>"></a>
                                <span class="blogitem-date"><?php echo e($blog->created_at); ?></span>
                            </div>
                            <div class="blogitem-content">
                                <div class="blogitem-header">
                                    <div class="blogitem-meta">
                                        <span><i class="zmdi zmdi-account"></i>توسط <a href="javascript:void(0);">لیلا ساداتی</a></span>
                                        
                                    </div>
                                    <div class="blogitem-share">
                                        <ul class="list-unstyled mb-0">
                                            <li>
                                                <a href="https://twitter.com/share?url=https://sharkhar.net/blogs/<?php echo e($blog->slug); ?>"
                                                   title=" Share on Twitter">
                                                    <i class="zmdi zmdi-twitter-box"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="https://www.linkedin.com/shareArticle?mini=true&amp;url=https://sharkhar.net/blogs/<?php echo e($blog->slug); ?>"
                                                   title=" Share on Linkedin">
                                                    <i class="zmdi zmdi-linkedin-box"></i>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="https://www.facebook.com/sharer/sharer.php?u=https://sharkhar.net/blogs/<?php echo e($blog->slug); ?>"
                                                   title=" Share on Facebook">
                                                    <i class="zmdi zmdi-facebook-box"></i>
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                                <h5><a href="<?php echo e(route('blogs.show',$blog->slug)); ?>"><?php echo e($blog->title); ?></a></h5>

                                <a href="<?php echo e(route('blogs.show',$blog->slug)); ?>" class="btn btn-info">ادامه مطلب</a>
                            </div>
                        </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($blogs->hasPages()  ): ?>
                    <div class="card">
                        <div class="body">
                            <div class="col-lg-12">
                                <?php echo e($blogs->links('vendor.pagination.custom')); ?>

                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <?php echo $__env->make('blog.side-bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout',['title' => 'فروشگاه','b_level2'=>'','hide'=>'true'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/blog/index.blade.php ENDPATH**/ ?>