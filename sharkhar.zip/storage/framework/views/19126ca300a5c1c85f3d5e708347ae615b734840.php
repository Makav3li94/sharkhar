

<?php $__env->startSection('content'); ?>


    <div class="container">
        <div class="row clearfix">


                <div class="card">
                    <div class="header">
                        <h2><strong>لیست</strong> تیکت ها</h2>
                    </div>
                    <div class="body">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                        <?php if($tickets->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                    <tr>
                                        <th class="nono">#</th>
                                        <th>عنوان</th>
                                        <th>تاریخ</th>
                                        <th>وضعیت</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="nono"><strong><?php echo e($key + 1); ?></strong></td>
                                            <td><?php echo e($ticket->subject); ?></td>
                                            <td><?php echo e($ticket->created_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('seller.contacts.edit',$ticket->id)); ?>">
                                                    <span class="badge badge-<?php echo e($ticket->status); ?>">
                                                        <?php if($ticket->status == 'success'): ?>
                                                                پاسخ داده شده
                                                            <?php elseif($ticket->status == 'info'): ?>
                                                                در حال بررسی
                                                            <?php else: ?>
                                                            بسته شده
                                                        <?php endif; ?>
                                                    </span>
                                                </a>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    <?php echo e($tickets->links('vendor.pagination.custom')); ?>

                                </table>
                            </div>
                        <?php else: ?>
                                <div class="card">
                                    <div class="body">
                                        <p class="text-primary text-center m-0">
                                            شما تیکتی ارسال نکرده اید.
                                        </p>
                                    </div>
                                </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_layout',['title' => 'لیست تیکت ها','b_level2'=>'لیست تیکت ها','back'=>'true'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/seller/contact/index.blade.php ENDPATH**/ ?>