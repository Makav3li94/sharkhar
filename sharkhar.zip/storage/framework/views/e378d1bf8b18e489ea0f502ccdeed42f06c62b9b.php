

<?php $__env->startSection('content'); ?>

        <div class="container">
            <div class="row clearfix">
                <div class="card">
                           <div class="body">
                        <form action="<?php echo e(route('seller.products.update',$product->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <div class="row clearfix mb-2">
                                <div class="col-lg-4 col-md-12">
                                    <div class="card mcard_3">
                                        <div class="body">
                                            <img src="<?php echo e($product->image_thumb ?? ''); ?>" class="rounded-circle shadow "
                                                 alt="profile-image">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-8 col-md-12">
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 mb-4">
                                            <label>عنوان محصول</label>
                                            <div class="input-group masked-input">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"><i
                                                                class="zmdi zmdi-text-format"></i></span>
                                                </div>
                                                <input class="form-control" name="title"
                                                       value="<?php echo e($product->title ?? old('title')); ?>"
                                                       type="text">
                                                <?php if($errors->has('title')): ?>
                                                    <small class="text-danger d-inline-block w-100  mt-2">
                                                        <?php echo e($errors->first('title')); ?>

                                                    </small>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 mb-4">
                                            <label>قیمت محصول</label>
                                            <div class="input-group masked-input">
                                                <div class="input-group-prepend">
                                                    <span class="input-group-text"><i
                                                                class="zmdi zmdi-money"></i></span>
                                                </div>
                                                <input class="form-control" name="price"
                                                       value="<?php echo e($product->price ?? old('price')); ?>"
                                                       type="text">
                                                <?php if($errors->has('price')): ?>
                                                    <small class="text-danger d-inline-block w-100  mt-2">
                                                        <?php echo e($errors->first('price')); ?>

                                                    </small>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6">
                                            <label>وضعیت محصول</label>
                                            <select name="status" class="form-control show-tick ms select2"
                                                    data-placeholder="انتخاب">
                                                <option value="1" <?php echo e($product->status == 1 ? 'selected' : ''); ?>>فعال
                                                </option>
                                                <option value="0" <?php echo e($product->status == 0 ? 'selected' : ''); ?>>غیر فعال
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 mb-3">



                                <div class="input-group">

                                    <textarea name="body" rows="5" class="summernote"><?php echo $product->body; ?></textarea>
                                </div>

                                <?php if($errors->has('body')): ?>
                                    <small class="text-danger d-inline-block w-100  mt-2">
                                        <?php echo e($errors->first('body')); ?>

                                    </small>
                                <?php endif; ?>
                            </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-raised btn-primary btn-round waves-effect">
                                    ذخیره تغییرات
                                </button>
                            </div>
                        </form>
                    </div>
                </div>


            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        small {
            text-align: right !important;
            margin-bottom: 5px;
        }
        .note-editor{
            width: 100%;
        }
    </style>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/summernote/dist/summernote.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/summernote/dist/summernote.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout',['title' => 'ویرایش محصول','b_level1'=>'محصولات','b_level2'=>'ویرایش محصول #' .$product->id,'back'=>'true'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/seller/product/edit.blade.php ENDPATH**/ ?>