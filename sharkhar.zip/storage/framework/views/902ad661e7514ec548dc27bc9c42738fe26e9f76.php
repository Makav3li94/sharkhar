
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row clearfix">
            <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div class="card">
                        <div class="body product_item">

                            <span class="badge badge-<?php echo e($seller->is_verified == 1 ? 'succcess' : 'danger'); ?>"><?php echo e($seller->is_verified == 1 ? 'تایید هویت شده' : ''); ?></span>
                            <img src="<?php echo e($seller->logo); ?>" alt="Product" class="img-fluid cp_img"/>
                            <h2 class="text-blush font-14 pt-4"><?php echo e($seller->title); ?></h2>
                            <div class="product_details">
                                <a href="<?php echo e(route('vendor',$seller->id)); ?>"><?php echo e($seller->insta_logo); ?></a>
                                <ul class="product_price list-unstyled">
                                    <li class="old_price">دسته بندی فروشگاه : </li>
                                    <li class="new_price"><?php echo e($seller->category); ?></li>
                                </ul>
                            </div>
                            <div class="action text-center">
                                <a href="<?php echo e(route('vendor',$seller->insta_user)); ?>" class="btn btn-info waves-effect">
                                    <i class="zmdi zmdi-eye"></i>
                                </a>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout',['title' => 'فروشگاه','b_level2'=>'فروشگاه'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/shop/index.blade.php ENDPATH**/ ?>