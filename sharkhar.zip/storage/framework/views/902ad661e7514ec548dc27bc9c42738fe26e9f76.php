
<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="row clearfix">


               <?php $__currentLoopData = $best; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $besty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                   <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                       <div class="card">
                           <div class="header">
                               <h3><strong>فروشگاه </strong> برتر</h3>
                           </div>
                           <div class="body product_item shop-box">

                               <span class="badge badge-<?php echo e($besty->is_verified == 1 ? 'succcess' : 'danger'); ?>"><?php echo e($besty->is_verified == 1 ? 'تایید هویت شده' : ''); ?></span>
                               <a href="<?php echo e(route('vendor',$besty->insta_user)); ?>">
                                   <span class="label" style="background-color: #3c763d;top: 100px!important;">تایید هویت شده</span>
                                   <img src="<?php echo e($besty->logo); ?>" alt="Product" class="cp_img"/>
                               </a>
                               <h2 class="text-blush text-center font-14 pt-4">
                                   <a href="<?php echo e(route('vendor',$besty->insta_user)); ?>">
                                       <?php echo e($besty->title); ?>

                                   </a>
                               </h2>
                               <div class="product_details">
                                   <a href="<?php echo e(route('vendor',$besty->id)); ?>"><?php echo e($besty->insta_logo); ?></a>
                                   <?php if($besty->category != null): ?>
                                   <ul class="product_price list-unstyled">
                                       <li class="old_price">دسته:</li>
                                       <li class="new_price"><?php echo e(\Illuminate\Support\Str::limit($besty->category,15)); ?></li>
                                   </ul>
                                       <?php endif; ?>
                               </div>
                               <div class="action text-center">
                                   <a href="<?php echo e(route('vendor',$besty->insta_user)); ?>" class="btn btn-info waves-effect">
                                       <i class="zmdi zmdi-eye"></i>
                                   </a>

                               </div>
                           </div>
                       </div>
                   </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <hr>
        <div class="row clearfix">

            <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6">
                    <div class="card">
                        <div class="body product_item">

                            <span class="badge badge-<?php echo e($seller->is_verified == 1 ? 'succcess' : 'danger'); ?>"><?php echo e($seller->is_verified == 1 ? 'تایید هویت شده' : ''); ?></span>
                            <a href="<?php echo e(route('vendor',$seller->insta_user)); ?>">
                                <span class="label onsale">تایید نشده</span>
                            <img src="<?php echo e($seller->logo); ?>" alt="Product" class="cp_img"/>
                            </a>
                            <h2 class="text-blush text-center font-14 pt-4">
                                <a href="<?php echo e(route('vendor',$seller->insta_user)); ?>">
                                    <?php echo e($seller->title); ?>

                                </a>
                            </h2>
                            <div class="product_details">
                                <a href="<?php echo e(route('vendor',$seller->id)); ?>"><?php echo e($seller->insta_logo); ?></a>
                                <?php if($seller->category != null): ?>
                                <ul class="product_price list-unstyled">
                                    <li class="old_price">دسته:</li>
                                    <li class="new_price"><?php echo e(\Illuminate\Support\Str::limit($seller->category,15)); ?></li>
                                </ul>
                                    <?php endif; ?>
                            </div>
                            <div class="action text-center">
                                <a href="<?php echo e(route('vendor',$seller->insta_user)); ?>" class="btn btn-info waves-effect">
                                    <i class="zmdi zmdi-eye"></i>
                                </a>

                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <div class="row">
            <?php if($sellers->hasPages()  ): ?>
                <div class="card">
                    <div class="body">
                        <?php echo e($sellers->links('vendor.pagination.custom')); ?>

                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout',['title' => 'فروشگاه ها شرخر  | پرداخت امن، فروش آسان','b_level2'=>'فروشگاه ها شرخر  | پرداخت امن، فروش آسان'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/shop/index.blade.php ENDPATH**/ ?>