<?php if(!auth()->guard()->check() && !auth()->guard('buyer')->check()): ?>
    <?php $bib = 'bib' ?>
    <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        header {
            background-color: #405de6;
        }

        .header_area .top-header .navbar {
            box-shadow: none;
            margin-bottom: 0;
            min-height: 30px;
            padding: .5rem 1rem !important;
        }
        .header_area .navbar{
            box-shadow: none;
            margin-bottom: 0;
        }

        .header_area  .navbar-brand{
            border-bottom: none;
        }
    </style>
    <?php echo $__env->make('login-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        <?php if($errors->has('mobile') || $errors->has('password')): ?>
        $('#colorModal').modal('show');
        <?php endif; ?>
    </script>
<?php else: ?>
    <?php echo $__env->make('layouts.seller_includes.right_sidabar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/layouts/front_header.blade.php ENDPATH**/ ?>