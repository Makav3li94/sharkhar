<div class="col-lg-4 col-md-12">
    <div class="card">
        <div class="body search">
            <div class="input-group mb-0">
                <input type="text" class="form-control" placeholder="جستجو...">
                <div class="input-group-append">
                    <span class="input-group-text" id="basic-addon2"><i class="zmdi zmdi-search"></i></span>
                </div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="header">
            <h2><strong>دسته ها</strong></h2>
        </div>
        <div class="body">
            <ul class="list-unstyled mb-0 widget-categories">
                <?php $__currentLoopData = $blogCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a href="<?php echo e('blog',$blogCategory->slug); ?>">گزارش کسب و کار</a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
    <div class="card">
        <div class="header">
            <h2><strong>پست های</strong> اخیر</h2>
        </div>
        <div class="body">
            <ul class="list-unstyled mb-0 widget-recentpost">
                <?php $__currentLoopData = $blogsLatest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('blogs.show',$blog->slug)); ?>">
                            <img src="<?php echo e(asset($blog->image)); ?>" alt="blog thumbnail">
                        </a>
                        <div class="recentpost-content">
                            <a href="<?php echo e(route('blogs.show',$blog->slug)); ?>"><?php echo e($blog->title); ?></a>
                            <span><?php echo e($blog->created_at); ?></span>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>

    <div class="card">
        <div class="header">
            <h2><strong>ابرهای</strong> برچسب</h2>
        </div>
        <div class="body">
            <ul class="list-unstyled mb-0 tag-clouds">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><a href="javascript:void(0);" class="tag badge badge-default"><?php echo e($tag->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>


</div><?php /**PATH C:\wamp64\www\sharkhar\resources\views/blog/side-bar.blade.php ENDPATH**/ ?>