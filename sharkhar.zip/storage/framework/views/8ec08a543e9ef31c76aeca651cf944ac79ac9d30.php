<?php if(!auth()->guard()->check() && !auth()->guard('buyer')->check()): ?>
    <?php $bib = 'bib' ?>
    <?php echo $__env->make('login-modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        <?php if($errors->has('mobile') || $errors->has('password')): ?>
        $('#colorModal').modal('show');
        <?php endif; ?>
    </script>
<?php endif; ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/layouts/front_footer.blade.php ENDPATH**/ ?>