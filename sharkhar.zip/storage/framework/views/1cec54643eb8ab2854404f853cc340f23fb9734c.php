
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row clearfix">
            <div class="col-lg-6 col-md-12">
                <div class="card mcard_1">
                    <div class="body" data-intro="اطلاعات پیج شما ...">


                        <div class="img">
                            <img src="<?php echo e($seller->background ?? 'assets/images/image-gallery/2.jpg'); ?>" class="img-fluid"
                                 alt="">

                        </div>
                        <div class="body">
                            <div class="user">
                                <img src="<?php echo e($seller->logo); ?>" class="rounded-circle img-raised"
                                     alt="profile-image">
                                <h5 class="mt-3 mb-1"><?php echo e($seller->insta_user); ?></h5>
                                <span class="text-info"><?php echo e($seller->category); ?></span>
                                <p><?php echo $seller->bio; ?></p>
                            </div>
                            <div class="d-flex bd-highlight text-center mt-4">
                                <div class="flex-fill bd-highlight">
                                    <h5 class="mb-0"><?php echo e($seller->posts); ?></h5>
                                    <small>پست</small>
                                </div>
                                <div class="flex-fill bd-highlight">
                                    <h5 class="mb-0"><?php echo e(number_format($seller->followers)); ?></h5>
                                    <small>دنبال کننده</small>
                                </div>
                                <div class="flex-fill bd-highlight">
                                    <h5 class="mb-0"><?php echo e(number_format($seller->following)); ?></h5>
                                    <small>دنبال کردن</small>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="col-lg-6 col-md-12" data-intro="آمار بازخورد های مشتریان شما پس از خرید از شرخر">
                <div class="card">
                    <div class="body">
                        <?php if(count($feedbacks) > 0): ?>
                            <ul class="row list-unstyled c_review">
                                <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="col-12">
                                        <div class="avatar">
                                            <a href="javascript:void(0);">
                                                <img class="rounded"
                                                     src="<?php echo e(asset('assets/images/user-placeholder.png')); ?>"
                                                     alt="user" width="60"></a>
                                        </div>
                                        <div class="comment-action">
                                            <h6 class="c_name"><?php echo e($feedback->buyer->name); ?></h6>
                                            <p class="c_msg m-b-0"><?php echo e(\Illuminate\Support\Str::limit($feedback->body,70)); ?> </p>
                                            <div class="badge badge-info"><?php echo e(\Illuminate\Support\Str::limit($feedback->product->title,15)); ?></div>
                                            <span class="m-l-10" style="position:absolute ;top:39px">
                                            <?php if($feedback->score == 'green'): ?>
                                                    <a href="javascript:void(0);"><i
                                                                class="zmdi zmdi-star col-amber"></i></a>
                                                    <a href="javascript:void(0);"><i
                                                                class="zmdi zmdi-star col-amber"></i></a>
                                                    <a href="javascript:void(0);"><i
                                                                class="zmdi zmdi-star col-amber"></i></a>
                                                <?php elseif($feedback->score == 'warning'): ?>
                                                    <a href="javascript:void(0);"><i
                                                                class="zmdi zmdi-star col-amber"></i></a>
                                                    <a href="javascript:void(0);"><i
                                                                class="zmdi zmdi-star col-amber"></i></a>
                                                    <a href="javascript:void(0);"><i
                                                                class="zmdi zmdi-star-outline text-muted"></i></a>
                                                <?php else: ?>
                                                    <a href="javascript:void(0);"><i
                                                                class="zmdi zmdi-star col-amber"></i></a>
                                                    <a href="javascript:void(0);"><i
                                                                class="zmdi zmdi-star-outline text-muted"></i></a>
                                                    <a href="javascript:void(0);"><i
                                                                class="zmdi zmdi-star-outline text-muted"></i></a>
                                                <?php endif; ?>
                                        </span>
                                            <small class="comment-date float-sm-right pt-1"><?php echo e($feedback->created_at); ?></small>
                                        </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php else: ?>
                            <p class="text-primary text-center m-0">
                                فعلا بازخوردی ثبت نشده :(
                            </p>
                            <hr>
                        <?php endif; ?>
                        <div class="user">
                            <div class="d-flex">
                                <h2 class="font-18 flex-grow-1 mb-0"><?php echo e($seller->name); ?>


                                </h2>
                                <div class=" badge  badge-<?php echo e($sellerColor); ?>  "><?php echo e($sellerIsVerified); ?></div>
                            </div>
                            <hr>
                            <span class="text-info"><?php echo e($seller->mobile); ?></span>
                            <br>
                            <span class="text-info"><strong>مجموع بازخورد
                                    ها:</strong> ' <?php echo e($seller->feedbacks->count()); ?></span>
                            <ul class="list-unstyled mt-3 d-flex">
                                <li class="mr-3 p-2 mp-res badge badge-success"> عالی: <?php echo e($good); ?> :)</li>
                                <li class="mr-3 p-2 mp-res badge badge-info">معمولی: <?php echo e($normal); ?></li>
                                <li class="mr-3 p-2 mp-res badge badge-danger"> ضعیف :<?php echo e($bad); ?></li>
                            </ul>


                            <div class="progress m-b-5">
                                <div class="progress-bar progress-bar-success" style="width: <?php echo e($p_good); ?>%">
                                    <span class="sr-only"><?php echo e($p_good); ?>٪ کامل (موفقیت)</span>
                                </div>
                                <div class="progress-bar progress-bar-warning progress-bar-striped"
                                     style="width: <?php echo e($p_norm); ?>%">
                                    <span class="sr-only"><?php echo e($p_norm); ?>٪ کامل (هشدار)</span>
                                </div>
                                <div class="progress-bar progress-bar-danger" style="width: <?php echo e($p_bad); ?>%">
                                    <span class="sr-only"><?php echo e($p_bad); ?>٪ کامل (خطر)</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
        <div class="row clearfix">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6">
                    <div class="card" >
                        <div class="body product_item">
                            <span class="label onsale">فروشی!</span>
                            <img src="<?php echo e($product->image); ?>" alt="<?php echo e($seller->title); ?>" class="img-fluid cp_img"/>

                            <div class="d-flex mt-3">
                                <div class="pr-2 ml-auto">
                                    <i class="zmdi zmdi-thumb-up col-blue"></i>
                                    <span><?php echo e($product->like_count); ?> لایک</span>
                                </div>
                                <div class="pr-2">
                                    <i class="zmdi zmdi-comment-text col-red"></i>

                                    <span><?php echo e($product->comment_count); ?> نظر</span>
                                </div>
                            </div>
                            <hr>
                            <div class="product_details">
                                <a class="text-justify font-13 d-inline-block"
                                   href="<?php echo e(route('product',$product->id)); ?>"><?php echo e(\Illuminate\Support\Str::limit($product->title,80)); ?></a>

                                <ul class="product_price list-unstyled justify-content-center">
                                    <li class="new_price"><?php echo e(number_format($product->price)); ?> هزار تومان</li>
                                </ul>
                            </div>
                            <div class="action text-center">
                                <a href="<?php echo e(route('product',$product->id)); ?>"
                                   class="btn btn-raised btn-primary btn-round waves-effect">
                                    می خوامش !
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php if($products->hasPages()  ): ?>
            <div class="row clearfix">
                <div class="card">
                    <div class="body">
                        <?php echo e($products->links('vendor.pagination.custom')); ?>

                    </div>
                </div>
            </div>

        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {


        if (RegExp('multipage', 'gi').test(window.location.search)) {
            introJs().setOption('doneLabel', 'Next page').start().oncomplete(function () {
                    window.location.href = '<?php echo e(url("seller/products/?multipage=true")); ?>';
            });
        }

    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <style>
        @media  screen and ( max-width: 520px ) {

            li.page-item {
                display: none;
            }

            .page-item:first-child,
            .page-item:last-child,
            .page-item:nth-last-child(2),
            .page-item:nth-child(2),
            .page-item.active {
                display: block;
            }
        }

    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout',['title' => 'فروشگاه','b_level2'=>$seller->insta_user,'hide'=>'true'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/shop/vendor.blade.php ENDPATH**/ ?>