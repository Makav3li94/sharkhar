
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row clearfix">

            <div class="card">
                <div class="body">
                    <div class="d-flex justify-content-between">
                        <div class="p-2 ">
                            <h5><strong>شماره سفارش: </strong> #<?php echo e($order->id); ?></h5>
                        </div>

                        <div class="p-2">
                            <p class="mb-0"><strong>تاریخ سفارش: </strong><?php echo e($order->created_at); ?></p>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 p-0">
                                <address>
                                    <strong class=" pb-2">نام فروشنده: </strong><?php echo e($order->seller->name); ?><br>
                                    <?php echo e($buyer->address ?? ''); ?><br>
                                    <abbr title="Phone">ت:</abbr> <?php echo e($order->seller->mobile); ?><br>
                                    <abbr title="Phone">ت-ث:</abbr> <?php echo e($order->seller->telephone ?? ''); ?>

                                </address>
                            </div>
                            <div class="col-md-6 col-sm-6 p-0  text-right">
                                <p class="mb-0"><strong>وضعیت سفارش: </strong>
                                    <span class="badge badge-success"> در حال انجام
                                    </span>
                                </p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </div>


        <div class="row clearfix">
            <div class="card">
                <div class="body">
                    <div class="col-md-12">
                        <div>
                            <table class="table">
                                <thead>
                                <tr>
                                    <th width="60px">تصویر</th>
                                    <th class="nono">عنوان</th>
                                    <th>تعداد</th>
                                    <th>واحد</th>
                                    <th>مجموع</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td><img src="<?php echo e($order->product->image_thumb); ?>" width="40" alt="Product img">
                                    </td>
                                    <td class="nono"><?php echo e(\Illuminate\Support\Str::limit($order->product->title,20) ??''); ?></td>
                                    <td><?php echo e($order->qty ?? ''); ?></td>
                                    <td><?php echo e(number_format($order->product->price)); ?></td>
                                    <td><?php echo e(number_format($order->price)); ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row clearfix">
            <div class="card">
                <div class="body">
                    <form action="<?php echo e(route('payment')); ?>" method="post">
                        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                        <div class="row">
                            <?php echo csrf_field(); ?>
                            <div class="col-lg-4 col-sm-4 mb-5 ">
                                <ul class="list-unstyled price-list">
                                    <li class="d-flex justify-content-between">
                                        <div class="">
                                            <strong>قیمت محصول: </strong>
                                        </div>
                                        <div class="">
                                            <span><?php echo e($order->qty); ?> * <?php echo e(number_format($order->product->price)); ?></span>
                                        </div>
                                    </li>
                                    <li class="d-flex justify-content-between">
                                        <div class="">
                                            <strong>قیمت کل: </strong>
                                        </div>
                                        <div class="">
                                            <span> <?php echo e(number_format(($order->price) - ($order->shipping_cost)) ?? 0); ?></span>
                                        </div>
                                    </li>
                                    <li class="d-flex justify-content-between">
                                        <div class="">
                                            <strong>هزینه ارسال: </strong>
                                        </div>
                                        <div>
                                            <span><?php echo e($order->shipping_cost ?? 0); ?></span>
                                        </div>
                                    </li>

                                    <li class="d-flex justify-content-between text-danger">
                                        <div>
                                            <strong>تخفیف: </strong>
                                        </div>
                                        <div>
                                            <span><?php echo e(number_format($order->discount) ?? 0); ?></span>
                                        </div>
                                    </li>
                                </ul>
                                <hr>
                                <h5 class="mb-0 text-success text-center"> مبلغ قابل پرداخت
                                    : <?php echo e(number_format($order->price)); ?> هزار
                                    تومان</h5>
                            </div>
                            <div class="col-lg-3 nono">

                            </div>
                            <div class="col-lg-5 col-sm-8 ">
                                <textarea name="note" class="form-control" id="" rows="3"
                                          placeholder="اگر نکته ای در خصوص خرید مد نظرتون هست اینجا یادداشت کنید"></textarea>
                            </div>


                        </div>
                        <div class="row mt-2">
                            <div class="col-lg-12">
                                <div class="form-group text-center">
                                    <div class="radio inlineblock m-r-20">
                                        <input type="radio" name="payment_method" id="direct" class="with-gap" value="0"
                                               checked="">
                                        <label for="direct">واریز مستقیم به فروشنده</label>
                                    </div>
                                    <div class="radio inlineblock">
                                        <input type="radio" name="payment_method" id="police" class="with-gap" value="1"
                                        >
                                        <label for="police">استفاده از سیستم واسطه شرخر</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row mt-1">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-raised btn-primary btn-round waves-effect">
                                    پرداخت
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_layout',['title' => 'صفحه پرداخت','b_level2'=>$order->seller->insta_user,'hide'=>'true'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\sharkhar\resources\views/shop/payment.blade.php ENDPATH**/ ?>